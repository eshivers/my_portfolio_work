/*
 * CS2050 - Computer Science II - Summer 2021
 * Instructor: Thyago Mota
 * Description: Activity 03 - Bee
 */

public class Bee {

    public static final int WORKER = 0;
    public static final int DRONE  = 1;
    public static final int QUEEN  = 2;

    int type;
    String beehive;
    int x;
    int y;

    Bee(String beehive){
        this.type = WORKER;
        this.beehive = beehive;
        this.x = 0;
        this.y = 0;
    }

    Bee(String beehive,int type){
        if(type != WORKER && type != DRONE  && type != QUEEN){
            this.type = WORKER;
        } else {
            this.type = type;
        }
        this.beehive = beehive;
        this.x = 0;
        this.y = 0;
    }

    getTypeAsString(int type){
        
    }

}
