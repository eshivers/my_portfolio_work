/*
 * CS2050 - Computer Science II - Summer 2021
 * Instructor: Thyago Mota
 * Description: Hwk 01 - StudentDriver
 */

public class StudentDriver {

    public static void main(String[] args) {

        // TODO #5: instantiate a student object
        Student myStudent = new Student(1,"John","Meteorology");

        // TODO #6: display the student's major
        System.out.println(myStudent.getMajor());
    }
}
