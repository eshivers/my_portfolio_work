/*
 * CS2050 - Computer Science II - Summer 2021
 * Instructor: Thyago Mota
 * Description: Prg 02 - HasKey Interface
 */

public interface HasKey {
    String getKey();
}
